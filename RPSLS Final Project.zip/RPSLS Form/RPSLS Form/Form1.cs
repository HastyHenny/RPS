﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPSLS_Form
{
    public partial class Menu : Form
    {
        int rounds = 3;
        int timerPerRound = 4;
        bool gameOver = false;
        string[] computerchoiceList = { "rock", "paper", "scissors", "lizard", "spock", "rock", "spock", "scissors", "paper", "lizard" };
        int randomNumber = 0;
        Random rnd = new Random();
        string computerChoice;
        string playerChoice;
        int playerScore;
        int computerScore;

        public Menu()
        {
            InitializeComponent();
            timer1.Enabled = true;
            playerChoice = "none";
            lblCountdown.Text = "3";
        }

        private void btnrock_Click(object sender, EventArgs e)
        {
            playerChoice = "rock";
            picPlayer1.Image = Properties.Resources.The_Rock;
        }

        private void btnpaper_Click(object sender, EventArgs e)
        {
            playerChoice = "paper";
            picPlayer1.Image = Properties.Resources.Paper;
        }

        private void btnscissors_Click(object sender, EventArgs e)
        {
            playerChoice = "scissors";
            picPlayer1.Image = Properties.Resources.larry_scissors;
        }

        private void btnlizard_Click(object sender, EventArgs e)
        {
            playerChoice = "lizard";
            picPlayer1.Image = Properties.Resources.rango_lizard;
        }

        private void btnspock_Click(object sender, EventArgs e)
        {
            playerChoice = "spock";
            picPlayer1.Image = Properties.Resources.spock_cat;
        }
        private void btnreset_Click(object sender, EventArgs e)
        {
            playerScore = 0;
            computerScore = 0;
            rounds = 3;
            lblScore.Text = "Player: " + playerScore + " - " + "CPU: " + computerScore;
            playerChoice = "none";
            lblCountdown.Text = "3";
            timer1.Enabled = true;
            picPlayer1.Image = Properties.Resources.such_empty;
            picCPU1.Image = Properties.Resources.such_empty;
            gameOver = false;

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timerPerRound -= 1;
            lblCountdown.Text = timerPerRound.ToString();
            lblRounds.Text = "Rounds: " + rounds;
            if (timerPerRound < 1)
            {
                timer1.Enabled = false;

                timerPerRound = 4;
                randomNumber = rnd.Next(0, computerchoiceList.Length);
                computerChoice = computerchoiceList[randomNumber];
                switch (computerChoice)
                {

                    case "rock":
                        picCPU1.Image = Properties.Resources.The_Rock;
                        break;

                    case "paper":
                        picCPU1.Image = Properties.Resources.Paper;
                        break;

                    case "scissors":
                        picCPU1.Image = Properties.Resources.larry_scissors;
                        break;

                    case "lizard":
                        picCPU1.Image = Properties.Resources.rango_lizard;
                        break;

                    case "spock":
                        picCPU1.Image = Properties.Resources.spock_cat;
                        break;
                }
            }

            if (rounds > 0)
            {
                checkGame();
            }

            else
            {
                if(playerScore > computerScore)
                {
                    MessageBox.Show("Player won the game");
                }
                else
                {
                    MessageBox.Show("The Computer won the game");
                }

                gameOver = true;
            }
        }

        private void checkGame()
        {
            //Computer Wins start
            if (playerChoice == "rock" && computerChoice == "paper")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Paper covers Rock");
                startNextRound();
            }
            else if (playerChoice == "spock" && computerChoice == "paper")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Paper disproves Spock");
                startNextRound();
            }
            else if (playerChoice == "scissors" && computerChoice == "rock")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Rock destroys Scissors");
                startNextRound();
            }
            else if (playerChoice == "lizard" && computerChoice == "rock")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Rock crushes Lizard");
                startNextRound();
            }
            else if (playerChoice == "paper" && computerChoice == "scissors")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Scissors cut Paper");
                startNextRound();
            }
            else if (playerChoice == "lizard" && computerChoice == "scissors")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Scissors decapitate Lizard");
                startNextRound();
            }
            else if (playerChoice == "paper" && computerChoice == "lizard")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Lizard eats Paper");
                startNextRound();
            }
            else if (playerChoice == "spock" && computerChoice == "lizard")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Lizard poisons Spock");
                startNextRound();
            }
            else if (playerChoice == "scissors" && computerChoice == "spock")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Spock smashes Scissors");
                startNextRound();
            }
            else if (playerChoice == "rock" && computerChoice == "spock")
            {
                computerScore += 1;
                rounds -= 1;
                MessageBox.Show("Computer Wins, Spock vaporizes Rock");
                startNextRound();
            }
            //Player Wins start
            else if (playerChoice == "paper" && computerChoice == "rock")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Paper covers Rock");
                startNextRound();
            }
            else if (playerChoice == "paper" && computerChoice == "spock")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Paper disproves Spock");
                startNextRound();
            }
            else if (playerChoice == "rock" && computerChoice == "scissors")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Rock destroys Scissors");
                startNextRound();
            }
            else if (playerChoice == "rock" && computerChoice == "lizard")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Rock crushes Lizard");
                startNextRound();
            }
            else if (playerChoice == "scissors" && computerChoice == "paper")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Scissors cut Paper");
                startNextRound();
            }
            else if (playerChoice == "scissors" && computerChoice == "lizard")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Scissors decapitate Lizard");
                startNextRound();
            }
            else if (playerChoice == "lizard" && computerChoice == "paper")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Lizard eats Paper");
                startNextRound();
            }
            else if (playerChoice == "lizard" && computerChoice == "spock")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Lizard poisons Spock");
                startNextRound();
            }
            else if (playerChoice == "spock" && computerChoice == "scissors")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Spock smashes Scissors");
                startNextRound();
            }
            else if (playerChoice == "spock" && computerChoice == "rock")
            {
                playerScore += 1;
                rounds -= 1;
                MessageBox.Show("Player Wins, Spock vaporizes Rock");
                startNextRound();
            }
            //Ties start
            else if (playerChoice == "rock" && computerChoice == "rock")
            {
                rounds += 1;
                MessageBox.Show("It is a tie!");
                startNextRound();
            }
            else if (playerChoice == "paper" && computerChoice == "paper")
            {
                rounds += 1;
                MessageBox.Show("It is a tie!");
                startNextRound();
            }
            else if (playerChoice == "scissors" && computerChoice == "scissors")
            {
                rounds += 1;
                MessageBox.Show("It is a tie!");
                startNextRound();
            }
            else if (playerChoice == "lizard" && computerChoice == "lizard")
            {
                rounds += 1;
                MessageBox.Show("It is a tie!");
                startNextRound();
            }
            else if (playerChoice == "spock" && computerChoice == "spock")
            {
                rounds += 1;
                MessageBox.Show("It is a tie!");
                startNextRound();
            }
        }

            private void startNextRound()
        {
            if(gameOver == true)
            {




                return;
            }

            lblScore.Text = "Player: " + playerScore + " - " + "CPU: " + computerScore;
            playerChoice = "none";
            timer1.Enabled = true;
            picPlayer1.Image = Properties.Resources.such_empty;
            picCPU1.Image = Properties.Resources.such_empty;

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}
