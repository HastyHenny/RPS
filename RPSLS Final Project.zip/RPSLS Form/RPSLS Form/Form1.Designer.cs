﻿namespace RPSLS_Form
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnrock = new System.Windows.Forms.Button();
            this.btnpaper = new System.Windows.Forms.Button();
            this.btnscissors = new System.Windows.Forms.Button();
            this.btnlizard = new System.Windows.Forms.Button();
            this.btnspock = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.PlayerName = new System.Windows.Forms.Label();
            this.CPUName = new System.Windows.Forms.Label();
            this.lblCountdown = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblRounds = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.picCPU1 = new System.Windows.Forms.PictureBox();
            this.picPlayer1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCPU1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnrock
            // 
            this.btnrock.BackColor = System.Drawing.Color.Gray;
            this.btnrock.Location = new System.Drawing.Point(28, 111);
            this.btnrock.Name = "btnrock";
            this.btnrock.Size = new System.Drawing.Size(75, 23);
            this.btnrock.TabIndex = 0;
            this.btnrock.Text = "Rock";
            this.btnrock.UseVisualStyleBackColor = false;
            this.btnrock.Click += new System.EventHandler(this.btnrock_Click);
            // 
            // btnpaper
            // 
            this.btnpaper.BackColor = System.Drawing.Color.White;
            this.btnpaper.Location = new System.Drawing.Point(28, 150);
            this.btnpaper.Name = "btnpaper";
            this.btnpaper.Size = new System.Drawing.Size(75, 23);
            this.btnpaper.TabIndex = 1;
            this.btnpaper.Text = "Paper";
            this.btnpaper.UseVisualStyleBackColor = false;
            this.btnpaper.Click += new System.EventHandler(this.btnpaper_Click);
            // 
            // btnscissors
            // 
            this.btnscissors.BackColor = System.Drawing.Color.DarkRed;
            this.btnscissors.Location = new System.Drawing.Point(28, 192);
            this.btnscissors.Name = "btnscissors";
            this.btnscissors.Size = new System.Drawing.Size(75, 23);
            this.btnscissors.TabIndex = 2;
            this.btnscissors.Text = "Scissors";
            this.btnscissors.UseVisualStyleBackColor = false;
            this.btnscissors.Click += new System.EventHandler(this.btnscissors_Click);
            // 
            // btnlizard
            // 
            this.btnlizard.BackColor = System.Drawing.Color.Green;
            this.btnlizard.Location = new System.Drawing.Point(28, 233);
            this.btnlizard.Name = "btnlizard";
            this.btnlizard.Size = new System.Drawing.Size(75, 23);
            this.btnlizard.TabIndex = 3;
            this.btnlizard.Text = "Lizard";
            this.btnlizard.UseVisualStyleBackColor = false;
            this.btnlizard.Click += new System.EventHandler(this.btnlizard_Click);
            // 
            // btnspock
            // 
            this.btnspock.BackColor = System.Drawing.Color.DarkCyan;
            this.btnspock.Location = new System.Drawing.Point(28, 274);
            this.btnspock.Name = "btnspock";
            this.btnspock.Size = new System.Drawing.Size(75, 23);
            this.btnspock.TabIndex = 4;
            this.btnspock.Text = "Spock";
            this.btnspock.UseVisualStyleBackColor = false;
            this.btnspock.Click += new System.EventHandler(this.btnspock_Click);
            // 
            // btnreset
            // 
            this.btnreset.Location = new System.Drawing.Point(688, 396);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 23);
            this.btnreset.TabIndex = 5;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // PlayerName
            // 
            this.PlayerName.AutoSize = true;
            this.PlayerName.Location = new System.Drawing.Point(218, 95);
            this.PlayerName.Name = "PlayerName";
            this.PlayerName.Size = new System.Drawing.Size(45, 13);
            this.PlayerName.TabIndex = 8;
            this.PlayerName.Text = "Player 1";
            // 
            // CPUName
            // 
            this.CPUName.AutoSize = true;
            this.CPUName.Location = new System.Drawing.Point(550, 95);
            this.CPUName.Name = "CPUName";
            this.CPUName.Size = new System.Drawing.Size(29, 13);
            this.CPUName.TabIndex = 9;
            this.CPUName.Text = "CPU";
            // 
            // lblCountdown
            // 
            this.lblCountdown.AutoSize = true;
            this.lblCountdown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountdown.Location = new System.Drawing.Point(391, 192);
            this.lblCountdown.Name = "lblCountdown";
            this.lblCountdown.Size = new System.Drawing.Size(19, 20);
            this.lblCountdown.TabIndex = 10;
            this.lblCountdown.Text = "3";
            this.lblCountdown.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(342, 68);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(98, 40);
            this.lblScore.TabIndex = 11;
            this.lblScore.Text = "Player 1 : 0\r\n CPU : 0\r\n";
            this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblScore.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblRounds
            // 
            this.lblRounds.AutoSize = true;
            this.lblRounds.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRounds.Location = new System.Drawing.Point(341, 389);
            this.lblRounds.Name = "lblRounds";
            this.lblRounds.Size = new System.Drawing.Size(124, 29);
            this.lblRounds.TabIndex = 12;
            this.lblRounds.Text = "Round : 3";
            this.lblRounds.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRounds.Click += new System.EventHandler(this.label3_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // picCPU1
            // 
            this.picCPU1.Image = global::RPSLS_Form.Properties.Resources.such_empty;
            this.picCPU1.Location = new System.Drawing.Point(467, 111);
            this.picCPU1.Name = "picCPU1";
            this.picCPU1.Size = new System.Drawing.Size(183, 186);
            this.picCPU1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCPU1.TabIndex = 7;
            this.picCPU1.TabStop = false;
            // 
            // picPlayer1
            // 
            this.picPlayer1.Image = global::RPSLS_Form.Properties.Resources.such_empty;
            this.picPlayer1.Location = new System.Drawing.Point(151, 111);
            this.picPlayer1.Name = "picPlayer1";
            this.picPlayer1.Size = new System.Drawing.Size(183, 186);
            this.picPlayer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPlayer1.TabIndex = 6;
            this.picPlayer1.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRounds);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblCountdown);
            this.Controls.Add(this.CPUName);
            this.Controls.Add(this.PlayerName);
            this.Controls.Add(this.picCPU1);
            this.Controls.Add(this.picPlayer1);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnspock);
            this.Controls.Add(this.btnlizard);
            this.Controls.Add(this.btnscissors);
            this.Controls.Add(this.btnpaper);
            this.Controls.Add(this.btnrock);
            this.Name = "Menu";
            this.Text = "RPSLS";
            ((System.ComponentModel.ISupportInitialize)(this.picCPU1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnrock;
        private System.Windows.Forms.Button btnpaper;
        private System.Windows.Forms.Button btnscissors;
        private System.Windows.Forms.Button btnlizard;
        private System.Windows.Forms.Button btnspock;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.PictureBox picPlayer1;
        private System.Windows.Forms.PictureBox picCPU1;
        private System.Windows.Forms.Label PlayerName;
        private System.Windows.Forms.Label CPUName;
        private System.Windows.Forms.Label lblCountdown;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblRounds;
        private System.Windows.Forms.Timer timer1;
    }
}

